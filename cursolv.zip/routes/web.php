<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\InventarioController;
use App\Http\Controllers\EmpresasController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});
/*Route::get('/inventario', function () {
    return view('inventario.index');
});*/
//Route::get('/inventario',[InventarioController::class,'index']);

//'register'=>false,
Route::resource('empresas', EmpresasController::class)->middleware('auth');
Route::resource('inventario',InventarioController::class)->middleware('auth');
Auth::routes(['register'=>false,'reset'=>false]);

Route::get('/home', [InventarioController::class, 'index'])->name('home');
Route::group(['middleware'=> 'auth'], function (){
    Route::get('/', [InventarioController::class, 'index'])->name('home');
});

//https://www.youtube.com/watch?v=9DU7WLZeam8 enlace del video donde estoy aprendiendo hacer esto