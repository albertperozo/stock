

<?php $__env->startSection('content'); ?>
    <div class="container">
        <form method="GET" action="<?php echo e(route('inventario.index')); ?>">
            <table>
                <tr>
                    <td>
                        <input class="form-control" type="text" name="search" placeholder="ingrese para buscar...">
                    </td>
                    <td>
                    <button class="btn btn-primary" type="submit">Buscar</button>
                    </td>
                </tr>
                <tr><td><br></td><td></td></tr>
            </table>
        </form>
    <?php if($consulta->isEmpty()): ?>
        <div class="alert alert-danger" role="alert">
            <p>No se encontraron resultados.</p>
        </div>
        
    <?php else: ?>
        <h3 class="font-weight-bold "><?php echo e($consulta->first()->empresa->nomEmpresa); ?> </h3>
        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Codigo</th>
                        <th>Descripcion</th>
                        <th>Grupo</th>
                        <th>Sub Grupo</th>
                        <th>Existencia</th>
                        <th>Precio 1</th>
                        <th>Precio 2</th>
                        <th>Precio 3</th>
                        <th>Precio 4</th>
                        <th>Precio 5</th>
                        <th>Costo Promedio</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $consulta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($inventario->id); ?></td>
                            <td><?php echo e($inventario->codProducto); ?></td>
                            <td><?php echo e($inventario->descripcionProducto); ?></td>
                            <td><?php echo e($inventario->descripcionGrupo); ?></td>
                            <td><?php echo e($inventario->descripcionSubGrupo); ?></td>
                            <td><?php echo e($inventario->existencia); ?></td>
                            <td><?php echo e($inventario->precioREF1); ?></td>
                            <td><?php echo e($inventario->precioREF2); ?></td>
                            <td><?php echo e($inventario->precioREF3); ?></td>
                            <td><?php echo e($inventario->precioREF4); ?></td>
                            <td><?php echo e($inventario->precioREF5); ?></td>
                            <td><?php echo e($inventario->costoPromedio); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="d-flex justify-content-center">
            <?php echo e($consulta->links('pagination::bootstrap-4')); ?>

        </div>
        <?php endif; ?>            
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxampp\htdocs\cursolv\resources\views/inventario/productos.blade.php ENDPATH**/ ?>