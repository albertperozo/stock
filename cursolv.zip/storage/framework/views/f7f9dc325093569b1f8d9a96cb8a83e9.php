

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Edicion de Inventario</h1>

        <form action="<?php echo e(url('/inventario/'.$producto->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('PATCH')); ?>

            <?php echo $__env->make('inventario.form',['modo'=>'Editar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxampp\htdocs\cursolv\resources\views/inventario/edit.blade.php ENDPATH**/ ?>