

<?php $__env->startSection('content'); ?>
<div class="container">
        <h1>Empresas</h1>

        <?php if(Session::has('mensaje')): ?>
            <?php echo e(Session::get('mensaje')); ?>

        <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Rif</th>
                        <th>Empresa</th>
                        <th>Estatus</th>
                        <th>ID Usuario</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($empresa->id); ?></td>
                        <td><?php echo e($empresa->codEmpresa); ?></td>
                        <td><?php echo e($empresa->nomEmpresa); ?></td>
                        <td><?php echo e($empresa->estatus); ?></td>
                        <td><?php echo e($empresa->uid); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="d-flex justify-content-center">
            <?php echo e($empresas->links('pagination::bootstrap-4')); ?>

        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxampp\htdocs\cursolv\resources\views/empresas/index.blade.php ENDPATH**/ ?>