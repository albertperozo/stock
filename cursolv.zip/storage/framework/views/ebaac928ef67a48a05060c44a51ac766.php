

<?php $__env->startSection('content'); ?>
<div class="container">
        <h1>Inventario</h1>

        <?php if(Session::has('mensaje')): ?>
            <?php echo e(Session::get('mensaje')); ?>

        <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Empresa</th>
                        <th>Codigo Producto</th>
                        <th>Descripcion Producto</th>
                        <th>Descripcion Grupo</th>
                        <th>Descripcion Sub Grupo</th>
                        <th>Existencia</th>
                        <th>Precio 1</th>
                        <th>Precio 2</th>
                        <th>Precio 3</th>
                        <th>Precio 4</th>
                        <th>Precio 5</th>
                        <th>Costo Promedio</th>
                        <!--th>Acciones </th-->

                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $inventario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($producto->id); ?></td>
                        <td><?php echo e($producto->id_empresa); ?></td>
                        <td><?php echo e($producto->codProducto); ?></td>
                        <td><?php echo e($producto->descripcionProducto); ?></td>
                        <td><?php echo e($producto->descripcionGrupo); ?></td>
                        <td><?php echo e($producto->descripcionSubGrupo); ?></td>
                        <td><?php echo e($producto->existencia); ?></td>
                        <td><?php echo e($producto->precioREF1); ?></td>
                        <td><?php echo e($producto->precioREF2); ?></td>
                        <td><?php echo e($producto->precioREF3); ?></td>
                        <td><?php echo e($producto->precioREF4); ?></td>
                        <td><?php echo e($producto->precioREF5); ?></td>
                        <td><?php echo e($producto->costoPromedio); ?></td>
                        <!--td>
                            <a href="<?php echo e(url('/inventario/'.$producto->id.'/edit')); ?>" class="btn btn-warning" >
                                Editar
                            </a>
                            |
                            <form action="<?php echo e(url('/inventario/'.$producto->id )); ?>" method="post" class="d-inline">
                                <?php echo csrf_field(); ?>
                                    <?php echo e(method_field('DELETE')); ?>

                                    <input type="submit" onclick="return confirm('¿Quieres borrar?')" value="Borrar" class="btn btn-danger">
                            </form>
                        </td-->
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="d-flex justify-content-center">
            <?php echo e($inventario->links('pagination::bootstrap-4')); ?>

        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxampp\htdocs\cursolv\resources\views/inventario/index.blade.php ENDPATH**/ ?>