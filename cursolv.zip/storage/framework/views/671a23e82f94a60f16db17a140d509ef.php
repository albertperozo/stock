
<?php if(auth()->guard()->check()): ?>        
    <?php if(auth()->id() == 1): ?>
        <li class="nav-item">
            <a href="<?php echo e(url('empresas/')); ?>" class="nav-link" >
                Empresas
            </a>
        </li>        
        <li class="nav-item">
            <a href="<?php echo e(url('inventario/')); ?>" class="nav-link" >
                Inventario
            </a>
        </li>
    <?php endif; ?>
    <?php endif; ?>
    <li class="nav-item active">
        <a href="<?php echo e(url('inventario/')); ?>" class="nav-link" >
            Productos
        </a>
    </li><?php /**PATH C:\xxampp\htdocs\cursolv\resources\views/_menu.blade.php ENDPATH**/ ?>