<?php

namespace App\Http\Controllers;

use App\Models\Inventario;
use Illuminate\Http\Request;

use function Laravel\Prompts\select;
use App\Models\Empresas;

class InventarioController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $user_id = auth()->id();
        $search = $request->input('search'); // Datos suministrados por el usuario desde el formulario    
        // Construir la consulta
        $consulta = Inventario::whereHas('empresa', function ($query) use ($user_id) {
            $query->where('uid', $user_id);
        })
        ->where(function ($query) use ($search) {
            $query->where('codProducto', 'LIKE', '%'.$search.'%')
                ->orWhere('descripcionProducto', 'LIKE', '%'.$search.'%')
                ->orWhere('descripcionGrupo', 'LIKE', '%'.$search.'%')
                ->orWhere('descripcionSubGrupo', 'LIKE', '%'.$search.'%');
        })
        ->with(['empresa:id,nomEmpresa'])
        ->paginate(10);
    
        return view('inventario.productos', compact('consulta'));
    }


    public function empresasproductos(){

        $empresasConInventarios = Empresas::with('listarproductos')->get();
        return view('inventario.listado', compact('empresasConInventarios'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        return redirect('inventario')->with('mensaje','Registro agregado correctamente!');
    }

    /**
     * Display the specified resource.
     */
    public function show(Request $request)
    {
        //
       /* $user_id = auth()->id();
        //
        $buscar = $request->input('buscar');        
        $empresasConInventarios='';
        if($user_id == 1){
            $empresasConInventarios = Empresas::with('inventarios')->paginate(2); // Cambia 10 por el número de elementos por página que deseas mostrar
        }else{
            
            $empresasConInventarios = Empresas::where('uid', $user_id)->with('inventarios')->paginate(10);
        }
        if ($buscar) {
            // Aplicar el filtro de búsqueda a las empresas y productos
            $empresasConInventarios = $empresasConInventarios->filter(function ($empresa) use ($buscar) {
                return stristr($empresa->nombre, $buscar) !== false || // ajusta según tus campos
                       stristr($empresa->inventarios->pluck('descripcionProducto')->implode(','), $buscar) !== false; // ajusta según tus campos
            });
        }
        return view('inventario.listado', compact('empresasConInventarios'));*/
        /*$user_id = auth()->id();
        $buscar = $request->input('buscar');
        $empresasConInventariosQuery = Empresas::with(['inventarios' => function ($query) use ($buscar) {
            $query->where('descripcionProducto', 'like', '%'.$buscar.'%');
        }]);
        if ($user_id != 1) {
            $empresasConInventariosQuery->where('uid', $user_id);
        }
        $empresasConInventarios = $empresasConInventariosQuery->paginate(10);
        return view('inventario.listado', compact('empresasConInventarios'));*/
         //este codigo de aqui en adelante funciona y es el que esta en la web
        /*$user_id = auth()->id();
        $buscar = $request->input('buscar');
        $empresasConInventariosQuery = Empresas::with(['inventarios' => function ($query) use ($buscar) {
            $query->where('codProducto', 'like', '%'.$buscar.'%')
                ->orWhere('descripcionProducto', 'like', '%'.$buscar.'%')
                ->orWhere('descripcionGrupo', 'like', '%'.$buscar.'%')
                ->orWhere('descripcionSubGrupo', 'like', '%'.$buscar.'%');
                //->paginate(10);
        }]);
        if ($user_id != 1) {
            $empresasConInventariosQuery->where('uid', $user_id);
        }
        
        $empresasConInventarios = $empresasConInventariosQuery->paginate(1);
        
        return view('inventario.listado', compact('empresasConInventarios'));*/
     
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        //
        $producto = Inventario::findOrFail($id);
        return view('inventario.edit', compact('producto'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        //
        //$datosProductos = $request()->except(['_token','_method']);
        $datosProductos = $request->except(['_token','_method','id_producto']);
        Inventario::where('id','=',$id)->update($datosProductos);
        $producto = Inventario::findOrFail($id);
        return view('inventario.edit', compact('producto'));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //
        Inventario::destroy($id);
        return redirect('inventario')->with('mensaje','Registro eliminado correctamente!');
    }
}
