<?php

namespace App\Http\Controllers;

use App\Models\Empresas;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;


class EmpresasController extends Controller
{
    //
    public function index()
    {
        //
        $datos['empresas'] = Empresas::paginate(10);
        return view('empresas.index',$datos);
    }    
}
