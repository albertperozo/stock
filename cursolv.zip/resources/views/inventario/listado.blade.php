@extends('layouts.app')

@section('content')
    <div class="container">
        <form method="GET" action="{{ route('inventario.show','inventarios') }}">
            <!--div class="form-row"-->
                    <table>
                        <tr>
                            <td>
                                <input class="form-control" type="text" name="buscar" placeholder="ingrese para buscar...">
                            </td>
                            <td>
                            <button class="btn btn-primary" type="submit">Buscar</button>
                            </td>
                        </tr>
                        <tr><td><br></td><td></td></tr>
                    </table>
                        
                        
                <!--/div-->
            
        </form>


    @foreach ($empresasConInventarios as $empresa)
        <h1>{{ $empresa->nomEmpresa }}</h1>
        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Codigo Producto</th>
                        <th>Descripcion Producto</th>
                        <th>Descripcion Grupo</th>
                        <th>Descripcion Sub Grupo</th>
                        <th>Existencia</th>
                        <th>Precio 1</th>
                        <th>Precio 2</th>
                        <th>Precio 3</th>
                        <th>Precio 4</th>
                        <th>Precio 5</th>
                        <th>Costo Promedio</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($empresa->inventarios as $inventario)
                        <tr>
                            <td>{{ $inventario->id }}</td>
                            <td>{{ $inventario->codProducto }}</td>
                            <td>{{ $inventario->descripcionProducto }}</td>
                            <td>{{ $inventario->descripcionGrupo }}</td>
                            <td>{{ $inventario->descripcionSubGrupo }}</td>
                            <td>{{ $inventario->existencia }}</td>
                            <td>{{ $inventario->precioREF1 }}</td>
                            <td>{{ $inventario->precioREF2 }}</td>
                            <td>{{ $inventario->precioREF3 }}</td>
                            <td>{{ $inventario->precioREF4 }}</td>
                            <td>{{ $inventario->precioREF5 }}</td>
                            <td>{{ $inventario->costoPromedio }}</td>


                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

     @endforeach
    <div class="d-flex justify-content-center">
        {{ $empresasConInventarios->links('pagination::bootstrap-4') }}    
    </div>               
</div>
@endsection