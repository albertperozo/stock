
@auth        
    @if(auth()->id() == 1)
        <li class="nav-item">
            <a href="{{ url('empresas/')}}" class="nav-link" >
                Empresas
            </a>
        </li>        
        <li class="nav-item">
            <a href="{{ url('inventario/')}}" class="nav-link" >
                Inventario
            </a>
        </li>
    @endif
    @endauth
    <li class="nav-item active">
        <a href="{{ url('inventario/')}}" class="nav-link" >
            Productos
        </a>
    </li>